(function () {
  "use strict";

  var app = window.UmarPortfolio || {};
  var ready = app.whenReady || function (callback) { callback(); };
  var prefersReducedMotion = app.prefersReducedMotion || function () { return false; };

  function formatNumber(value, suffix) {
    return Math.round(value).toLocaleString() + (suffix || "");
  }

  ready(function () {
    var counters = Array.from(document.querySelectorAll("[data-counter]"));

    if (!counters.length) {
      return;
    }

    function animateCounter(counter) {
      if (counter.dataset.counted === "true") {
        return;
      }

      var target = Number(counter.getAttribute("data-target") || counter.textContent || 0);
      var suffix = counter.getAttribute("data-suffix") || "";
      var duration = Number(counter.getAttribute("data-duration") || 1200);
      var startTime = null;

      counter.dataset.counted = "true";

      if (prefersReducedMotion() || !Number.isFinite(target)) {
        counter.textContent = formatNumber(target || 0, suffix);
        return;
      }

      function step(timestamp) {
        if (!startTime) {
          startTime = timestamp;
        }

        var progress = Math.min((timestamp - startTime) / duration, 1);
        var easedProgress = 1 - Math.pow(1 - progress, 3);
        counter.textContent = formatNumber(target * easedProgress, suffix);

        if (progress < 1) {
          window.requestAnimationFrame(step);
        }
      }

      window.requestAnimationFrame(step);
    }

    if (!("IntersectionObserver" in window)) {
      counters.forEach(animateCounter);
      return;
    }

    var observer = new IntersectionObserver(
      function (entries, instance) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            animateCounter(entry.target);
            instance.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.35,
      }
    );

    counters.forEach(function (counter) {
      observer.observe(counter);
    });
  });
})();
