(function () {
  "use strict";

  var app = window.UmarPortfolio || {};
  var ready = app.whenReady || function (callback) { callback(); };

  ready(function () {
    var links = Array.from(document.querySelectorAll('.navbar .nav-link[href^="#"]'));

    if (!links.length) {
      return;
    }

    var sections = links
      .map(function (link) {
        return document.querySelector(link.getAttribute("href"));
      })
      .filter(Boolean);

    function setActive(sectionId) {
      links.forEach(function (link) {
        var isActive = link.getAttribute("href") === "#" + sectionId;
        link.classList.toggle("active", isActive);

        if (isActive) {
          link.setAttribute("aria-current", "page");
        } else {
          link.removeAttribute("aria-current");
        }
      });
    }

    function getCurrentSection() {
      var navbarHeight = Number.parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--navbar-height")) || 84;
      var current = sections[0];

      sections.forEach(function (section) {
        if (section.getBoundingClientRect().top <= navbarHeight + 80) {
          current = section;
        }
      });

      return current;
    }

    if (!sections.length) {
      return;
    }

    setActive(sections[0].id);

    if (!("IntersectionObserver" in window)) {
      window.addEventListener("scroll", function () {
        setActive(getCurrentSection().id);
      }, { passive: true });
      return;
    }

    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            setActive(entry.target.id);
          }
        });
      },
      {
        rootMargin: "-42% 0px -52% 0px",
        threshold: [0.1, 0.25, 0.5],
      }
    );

    sections.forEach(function (section) {
      observer.observe(section);
    });
  });
})();
