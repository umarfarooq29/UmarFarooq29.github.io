# Umar Farooq Portfolio

Modern static portfolio for Umar Farooq, built with HTML, CSS, JavaScript, and Bootstrap 5.3.

## Local Preview

Run a local static server from the project root:

```bash
python -m http.server 5500
```

Then open:

```text
http://localhost:5500/
```

Using a local server is recommended because the site loads JSON data files with `fetch()`.

## Deployment

This project can be deployed to any static host, including GitHub Pages, Netlify, Vercel, Cloudflare Pages, or shared hosting.

Before deploying:

1. Replace `https://umarfarooq.example.com/` with your real domain in `index.html`, `robots.txt`, and `sitemap.xml`.
2. Replace placeholder education and experience entries in `data/education.json` and `data/experience.json`.
3. Replace the placeholder CV at `assets/documents/Umar_Farooq_CV.pdf` with your final resume.
4. Upload the full project folder to your static hosting provider.

## Final Checks

```bash
node --check assets/js/main.js
node --check assets/js/navbar.js
node --check assets/js/darkmode.js
node --check assets/js/typewriter.js
node --check assets/js/particles.js
node --check assets/js/counter.js
node --check assets/js/skills.js
node --check assets/js/animation.js
node --check assets/js/scrollspy.js
node --check assets/js/contact.js
```
